﻿
namespace EnBuyukSayiyiGoster
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.itemListBox = new System.Windows.Forms.ListBox();
            this.itemInputTextBox = new System.Windows.Forms.TextBox();
            this.addItemButton = new System.Windows.Forms.Button();
            this.showResultButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // itemListBox
            // 
            this.itemListBox.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.itemListBox.FormattingEnabled = true;
            this.itemListBox.ItemHeight = 20;
            this.itemListBox.Location = new System.Drawing.Point(13, 13);
            this.itemListBox.Name = "itemListBox";
            this.itemListBox.Size = new System.Drawing.Size(248, 684);
            this.itemListBox.TabIndex = 0;
            // 
            // itemInputTextBox
            // 
            this.itemInputTextBox.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.itemInputTextBox.Location = new System.Drawing.Point(268, 13);
            this.itemInputTextBox.Name = "itemInputTextBox";
            this.itemInputTextBox.Size = new System.Drawing.Size(220, 27);
            this.itemInputTextBox.TabIndex = 1;
            // 
            // addItemButton
            // 
            this.addItemButton.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.addItemButton.Location = new System.Drawing.Point(268, 46);
            this.addItemButton.Name = "addItemButton";
            this.addItemButton.Size = new System.Drawing.Size(220, 28);
            this.addItemButton.TabIndex = 2;
            this.addItemButton.Text = "Ekle";
            this.addItemButton.UseVisualStyleBackColor = true;
            this.addItemButton.Click += new System.EventHandler(this.AddItemButtonClickListener);
            // 
            // showResultButton
            // 
            this.showResultButton.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.showResultButton.Location = new System.Drawing.Point(268, 80);
            this.showResultButton.Name = "showResultButton";
            this.showResultButton.Size = new System.Drawing.Size(220, 28);
            this.showResultButton.TabIndex = 3;
            this.showResultButton.Text = "Sonucu Yazdir";
            this.showResultButton.UseVisualStyleBackColor = true;
            this.showResultButton.Click += new System.EventHandler(this.ShowResultButtonClickListener);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1274, 716);
            this.Controls.Add(this.showResultButton);
            this.Controls.Add(this.addItemButton);
            this.Controls.Add(this.itemInputTextBox);
            this.Controls.Add(this.itemListBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox itemListBox;
        private System.Windows.Forms.TextBox itemInputTextBox;
        private System.Windows.Forms.Button addItemButton;
        private System.Windows.Forms.Button showResultButton;
    }
}

