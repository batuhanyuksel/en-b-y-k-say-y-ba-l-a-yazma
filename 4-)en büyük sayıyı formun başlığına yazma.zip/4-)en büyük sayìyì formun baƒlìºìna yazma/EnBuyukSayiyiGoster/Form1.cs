﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EnBuyukSayiyiGoster
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void ShowResultButtonClickListener(object sender, EventArgs e) // ShowResult butonuna tıklandığında çalışacak olan fonksiyon.
        {
            int biggestValue = 0; // Listedeki en büyük değeri tutacak olan değişken.

            foreach (int value in itemListBox.Items) // itemListBox ın içindeki öğelerde gezilir.
            {

                if (value > biggestValue) // eğer her gezinmede değişen value değeri biggestValue adlı değişkenden büyükse. BiggestValue değişkeni value değerine eşitlenir.

                {
                    biggestValue = value;
                }
            }

            this.Text = "En büyük sayı: " + biggestValue.ToString(); // Sonuç olarak biggest value değeri formun başlık çubuğuna string e çevirilerek bastırılır.
        }

        private void AddItemButtonClickListener(object sender, EventArgs e) // addItem butonuna basıldığında çalışacak olan fonksiyon.
        {
            // inputTextBox a girilen verileri bu fonksiyon her çalıştığında. Yani add item butonuna her tıklandığında integer veri tipine çevirip listeye eklenir.
            itemListBox.Items.Add(int.Parse(itemInputTextBox.Text)); 
            itemInputTextBox.Clear(); // öğe listeye eklendikten sonra textBox tan silinir.
        }
    }
}
